
import subprocess
import socket
import ssl
import sys
import threading

# DNS chain (can add more as needed)
DNS_CHAIN = [
    "8.8.8.8",         # Google DNS
    "1.1.1.1",         # Cloudflare DNS
    "208.67.222.222",  # OpenDNS
    "223.165.30.30",   # Jio DNS
]

def resolve_ip(domain):
    for dns in DNS_CHAIN:
        try:
            result = subprocess.run(
                ["dig", "+short", domain, f"@{dns}"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            ip = result.stdout.strip().split("\n")[0]
            if ip:
                return ip, dns
        except:
            continue
    return None, None

def tls_server_banner(domain, ip):
    try:
        ctx = ssl.create_default_context()
        conn = ctx.wrap_socket(socket.socket(), server_hostname=domain)
        conn.settimeout(5)
        conn.connect((ip, 443))
        cert = conn.getpeercert()
        server = cert.get('subject', [['unknown']])[0][0][1]
        conn.close()
        return server
    except:
        return "unknown"

def curl_http(domain, ip, method):
    try:
        cmd = [
            'curl',
            '-I' if method == 'HEAD' else '-i',
            '--resolve', f"{domain}:443:{ip}",
            f"https://{domain}",
            '--max-time', '10',
            '-k'
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        output = result.stdout
        code = '?'
        for line in output.splitlines():
            if line.startswith('HTTP/'):
                parts = line.split()
                if len(parts) >= 2:
                    code = parts[1]
                    break
        return code
    except:
        return '?'

def scan_sni(domain):
    ip, dns_used = resolve_ip(domain)
    if not ip:
        print(f"GET    ?    unknown        443 {domain:<25} ❌ DNS BLOCKED")
        return

    server = tls_server_banner(domain, ip)
    code = curl_http(domain, ip, 'GET')

    status = "✅ WORKING" if code in ['200', '301', '302'] else "❌ FAIL"
    print(f"GET    {code:<4} {server:<14} 443 {domain:<25} {status} ({dns_used})")

def start_scan(domains):
    threads = []
    for domain in domains:
        t = threading.Thread(target=scan_sni, args=(domain.strip(),))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

def main():
    while True:
        print("\n🌐 TSHACKER SNI SMART SCANNER 🌐")
        print("1️⃣ Scan single domain")
        print("2️⃣ Scan multiple domains (one per line, end with empty line)")
        print("3️⃣ Exit")
        choice = input("Select: ").strip()

        if choice == '1':
            domain = input("Enter SNI/domain: ").strip()
            print("\nMETHOD CODE SERVER         PORT SNI                       STATUS")
            print("-" * 80)
            scan_sni(domain)

        elif choice == '2':
            print("Enter multiple domains (one per line). End with empty line:")
            domains = []
            while True:
                d = input().strip()
                if d == "":
                    break
                domains.append(d)
            print("\nMETHOD CODE SERVER         PORT SNI                       STATUS")
            print("-" * 80)
            start_scan(domains)

        elif choice == '3':
            print("Exiting... 🚀")
            sys.exit(0)

        else:
            print("❗ Invalid option. Try again.")

if __name__ == "__main__":
    main()
