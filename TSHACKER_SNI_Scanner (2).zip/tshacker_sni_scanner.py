
import subprocess
import socket
import ssl
import sys
import threading
import dns.resolver

def resolve_ip(domain):
    try:
        resolver = dns.resolver.Resolver()
        resolver.nameservers = ['8.8.8.8', '1.1.1.1']
        answer = resolver.resolve(domain, 'A')
        return answer[0].to_text()
    except:
        return None

def tls_server_banner(domain, ip):
    try:
        ctx = ssl.create_default_context()
        conn = ctx.wrap_socket(socket.socket(), server_hostname=domain)
        conn.settimeout(10)
        conn.connect((ip, 443))
        cert = conn.getpeercert()
        server = cert.get('subject', [['unknown']])[0][0][1]
        conn.close()
        return server
    except:
        return "unknown"

def curl_http(domain, ip, method):
    try:
        cmd = [
            'curl',
            '-I' if method == 'HEAD' else '-i',
            '--resolve', f"{domain}:443:{ip}",
            f"https://{domain}",
            '--max-time', '10',
            '-k'
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        output = result.stdout
        code = '?'
        for line in output.splitlines():
            if line.startswith('HTTP/'):
                parts = line.split()
                if len(parts) >= 2:
                    code = parts[1]
                    break
        return code
    except:
        return '?'

def zero_data_test(domain, ip):
    try:
        cmd = [
            'curl',
            '--resolve', f"{domain}:443:{ip}",
            f"https://{domain}",
            '--max-time', '10',
            '-k',
            '--range', '0-0'
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if "HTTP/" in result.stdout:
            return True
        return False
    except:
        return False

def scan_sni(domain):
    ip = resolve_ip(domain)
    if not ip:
        print(f"{'GET':<6} {'?':<4} {'unknown':<14} 443 {domain:<25} ❌ DNS BLOCKED")
        return

    server = tls_server_banner(domain, ip)

    for method in ['GET']:
        code = curl_http(domain, ip, method)
        status = "❌ FAILED"
        if code.startswith('2'):
            if zero_data_test(domain, ip):
                status = "✅ BUG HOST"
            else:
                status = "❌ NO DATA (blocked)"
        elif code.startswith('3'):
            status = "❌ OPERATOR REDIRECT"
        elif code.startswith('4') or code.startswith('5'):
            status = "❌ FAILED"
        else:
            status = "❌ FAILED"

        print(f"{method:<6} {code:<4} {server:<14} 443 {domain:<25} {status}")

def start_scan(domains):
    threads = []
    for domain in domains:
        t = threading.Thread(target=scan_sni, args=(domain.strip(),))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

def main():
    while True:
        print("\n🌐 TSHACKER SNI SCANNER 🌐")
        print("1️⃣ Scan single domain")
        print("2️⃣ Scan multiple domains (one per line)")
        print("3️⃣ Scan from file")
        print("4️⃣ Exit")
        choice = input("Select: ").strip()

        if choice == '1':
            domain = input("Enter SNI/domain: ").strip()
            print(f"\n{'METHOD':<6} {'CODE':<4} {'SERVER':<14} PORT {'SNI':<25} STATUS")
            print('-' * 80)
            scan_sni(domain)
            post_scan_menu()

        elif choice == '2':
            print("Enter multiple domains (one per line). End with empty line:")
            domains = []
            while True:
                d = input()
                if d == '':
                    break
                domains.append(d.strip())
            print(f"\n{'METHOD':<6} {'CODE':<4} {'SERVER':<14} PORT {'SNI':<25} STATUS")
            print('-' * 80)
            start_scan(domains)
            post_scan_menu()

        elif choice == '3':
            file = input("Enter file path: ").strip()
            try:
                with open(file) as f:
                    domains = [line.strip() for line in f if line.strip()]
                print(f"\n{'METHOD':<6} {'CODE':<4} {'SERVER':<14} PORT {'SNI':<25} STATUS")
                print('-' * 80)
                start_scan(domains)
                post_scan_menu()
            except:
                print("❌ File not found or error reading file.")

        elif choice == '4':
            print("🚀 Exiting...")
            sys.exit(0)

        else:
            print("❌ Invalid option. Try again.")

def post_scan_menu():
    print("\nScan finished. What do you want to do?")
    print("1️⃣ Back to main menu")
    print("2️⃣ Exit")
    sel = input("Select: ").strip()
    if sel == '1':
        return
    else:
        print("🚀 Exiting...")
        sys.exit(0)

if __name__ == "__main__":
    main()
