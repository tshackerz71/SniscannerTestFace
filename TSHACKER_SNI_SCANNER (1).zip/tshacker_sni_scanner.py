
import subprocess
import socket
import ssl
import sys
import threading
import time

def resolve_ip(domain):
    try:
        ip = socket.gethostbyname(domain)
        return ip
    except:
        return None

def tls_server_banner(domain, ip):
    try:
        ctx = ssl.create_default_context()
        conn = ctx.wrap_socket(socket.socket(), server_hostname=domain)
        conn.settimeout(5)
        conn.connect((ip, 443))
        cert = conn.getpeercert()
        server = cert.get('subject', [['unknown']])[0][0][1]
        conn.close()
        return server
    except:
        return "unknown"

def curl_http(domain, ip, method):
    try:
        cmd = [
            'curl',
            '-I' if method == 'HEAD' else '-i',
            '--resolve', f"{domain}:443:{ip}",
            f"https://{domain}",
            '--max-time', '5',
            '-k', '-L'
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        output = result.stdout
        code = '?'
        server = 'unknown'
        for line in output.splitlines():
            if line.startswith('HTTP/'):
                parts = line.split()
                if len(parts) >= 2:
                    code = parts[1]
            if line.lower().startswith('server:'):
                server = line.split(':', 1)[1].strip()
        return code, server
    except:
        return '?', 'unknown'

def zero_data_check(domain, ip):
    try:
        cmd = [
            'curl',
            '--resolve', f"{domain}:443:{ip}",
            f"https://{domain}/tinyfile",
            '--max-time', '5',
            '-k', '-L', '--silent', '--output', '/dev/null'
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if result.returncode == 0:
            return True
        else:
            return False
    except:
        return False

def scan_sni(domain):
    ip = resolve_ip(domain)
    if not ip:
        print(f"{'GET':<6} {'?':<4} {'unknown':<15} 443 {domain:<20} ❌ DNS FAILED")
        return

    tls_server = tls_server_banner(domain, ip)

    code, server = curl_http(domain, ip, 'GET')

    if code.startswith('30'):
        status = '❌ OPERATOR REDIRECT'
    elif code == '200':
        if zero_data_check(domain, ip):
            status = '✅ BUG HOST (zero-data worked)'
        else:
            status = '❌ NO DATA (zero-data fail)'
    else:
        status = '❌ FAILED'

    print(f"{'GET':<6} {code:<4} {server:<15} 443 {ip:<15} {domain:<20} {status}")

def start_scan(domains):
    threads = []
    for domain in domains:
        t = threading.Thread(target=scan_sni, args=(domain.strip(),))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

def main():
    while True:
        print("\n🌐 TSHACKER SNI SCANNER 🌐")
        print("1️⃣ Scan single domain")
        print("2️⃣ Scan multiple domains (one per line, end with empty line)")
        print("3️⃣ Scan from file")
        print("4️⃣ Exit")
        choice = input("Select: ").strip()

        if choice == '1':
            domain = input("Enter SNI/domain: ").strip()
            print(f"\n{'METHOD':<6} {'CODE':<4} {'SERVER':<15} {'PORT'} {'IP':<15} {'SNI':<20} STATUS")
            print('-' * 90)
            scan_sni(domain)
            post_scan_menu()

        elif choice == '2':
            print("Enter multiple domains (one per line). End with empty line:")
            domains = []
            while True:
                line = input().strip()
                if not line:
                    break
                domains.append(line)
            print(f"\n{'METHOD':<6} {'CODE':<4} {'SERVER':<15} {'PORT'} {'IP':<15} {'SNI':<20} STATUS")
            print('-' * 90)
            start_scan(domains)
            post_scan_menu()

        elif choice == '3':
            filename = input("Enter file path: ").strip()
            try:
                with open(filename) as f:
                    domains = [line.strip() for line in f if line.strip()]
                print(f"\n{'METHOD':<6} {'CODE':<4} {'SERVER':<15} {'PORT'} {'IP':<15} {'SNI':<20} STATUS")
                print('-' * 90)
                start_scan(domains)
                post_scan_menu()
            except FileNotFoundError:
                print("❗ File not found.")

        elif choice == '4':
            print("Exiting... 🚀")
            sys.exit(0)

        else:
            print("❗ Invalid option. Try again.")

def post_scan_menu():
    while True:
        print("\nScan finished. What do you want to do?")
        print("1️⃣ Back to main menu")
        print("2️⃣ Exit")
        choice = input("Select: ").strip()
        if choice == '1':
            return
        elif choice == '2':
            print("Exiting... 🚀")
            sys.exit(0)
        else:
            print("❗ Invalid choice. Try again.")

if __name__ == "__main__":
    main()
