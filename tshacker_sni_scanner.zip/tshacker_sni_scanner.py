
import subprocess
import socket
import ssl
import sys
import threading

LICENSE_KEY = "tspapa71"

def resolve_ip(domain):
    try:
        ip = socket.gethostbyname(domain)
        return ip
    except:
        return "Resolution Failed"

def tls_server_banner(domain, ip):
    try:
        ctx = ssl.create_default_context()
        conn = ctx.wrap_socket(socket.socket(), server_hostname=domain)
        conn.settimeout(10)
        conn.connect((ip, 443))
        cert = conn.getpeercert()
        server = cert.get('subject', [['unknown']])[0][0][1]
        conn.close()
        return server
    except:
        return "unknown"

def curl_http(domain, ip, method):
    try:
        cmd = [
            'curl',
            '-I' if method == 'HEAD' else '-i',
            '--resolve', f"{domain}:443:{ip}",
            f"https://{domain}",
            '--max-time', '10',
            '-k'
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        output = result.stdout
        code = '?'
        for line in output.splitlines():
            if line.startswith('HTTP/'):
                parts = line.split()
                if len(parts) >= 2:
                    code = parts[1]
                    break
        return code
    except:
        return '?'

def scan_sni(domain):
    ip = resolve_ip(domain)
    if ip == "Resolution Failed":
        print(f"{'-':<6} {'-':<4} {'-':<15} 443   {'Resolution Failed':<15} {domain}")
        return

    server = tls_server_banner(domain, ip)

    for method in ['GET']:
        code = curl_http(domain, ip, method)
        print(f"{method:<6} {code:<4} {server:<15} 443   {ip:<15} {domain}")

def start_scan(domains):
    threads = []
    for domain in domains:
        t = threading.Thread(target=scan_sni, args=(domain.strip(),))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    while True:
        print("\n✅ Scan complete. What would you like to do?")
        print("1️⃣ Back to main menu")
        print("2️⃣ Exit")
        post = input("Select: ").strip()
        if post == '1':
            return
        elif post == '2':
            print("Exiting... 🚀")
            sys.exit(0)
        else:
            print("❗ Invalid option. Try again.")

def main():
    license_input = input("🔑 Enter license key: ").strip()
    if license_input != LICENSE_KEY:
        print("❌ Invalid license key! Exiting...")
        sys.exit(1)

    while True:
        print("\n🌐 TSHACKER SNI SCANNER 🌐")
        print("1️⃣ Scan single domain")
        print("2️⃣ Scan multiple domains (one domain per line)")
        print("3️⃣ Scan from file")
        print("4️⃣ Exit")
        print("9️⃣ Show license key info")
        choice = input("Select: ").strip()

        if choice == '1':
            domain = input("Enter SNI/domain: ").strip()
            print(f"\n{'METHOD':<6} {'CODE':<4} {'SERVER':<15} {'PORT':<5} {'IP':<15} SNI")
            print('-' * 70)
            start_scan([domain])

        elif choice == '2':
            print("Enter multiple domains (one per line). End with empty line:")
            domains = []
            while True:
                domain = input()
                if domain.strip() == '':
                    break
                domains.append(domain.strip())
            if domains:
                print(f"\n{'METHOD':<6} {'CODE':<4} {'SERVER':<15} {'PORT':<5} {'IP':<15} SNI")
                print('-' * 70)
                start_scan(domains)
            else:
                print("❗ No domains entered.")

        elif choice == '3':
            filename = input("Enter file path: ").strip()
            try:
                with open(filename) as f:
                    domains = [line.strip() for line in f if line.strip()]
                print(f"\n{'METHOD':<6} {'CODE':<4} {'SERVER':<15} {'PORT':<5} {'IP':<15} SNI")
                print('-' * 70)
                start_scan(domains)
            except FileNotFoundError:
                print("❗ File not found.")

        elif choice == '4':
            print("Exiting... 🚀")
            sys.exit(0)

        elif choice == '9':
            print(f"✅ License Key: {LICENSE_KEY} (VALID)")

        else:
            print("❗ Invalid option. Try again.")

if __name__ == "__main__":
    main()
