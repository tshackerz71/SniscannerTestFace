
import subprocess
import socket
import ssl
import sys
import threading

def resolve_ip(domain):
    try:
        ip = socket.gethostbyname(domain)
        return ip
    except:
        return "Resolution Failed"

def tls_server_banner(domain, ip):
    try:
        ctx = ssl.create_default_context()
        conn = ctx.wrap_socket(socket.socket(), server_hostname=domain)
        conn.settimeout(10)
        conn.connect((ip, 443))
        cert = conn.getpeercert()
        server = cert.get('subject', [['unknown']])[0][0][1]
        conn.close()
        return server
    except:
        return "unknown"

def curl_http(domain, ip, method):
    try:
        cmd = [
            'curl',
            '-I' if method == 'HEAD' else '-i',
            '--resolve', f"{domain}:443:{ip}",
            f"https://{domain}",
            '--max-time', '10',
            '-k'
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        output = result.stdout
        code = '?'
        for line in output.splitlines():
            if line.startswith('HTTP/'):
                parts = line.split()
                if len(parts) >= 2:
                    code = parts[1]
                    break
        return code
    except:
        return '?'

def scan_sni(domain):
    ip = resolve_ip(domain)
    if ip == "Resolution Failed":
        print(f"{domain:<18} | {'unknown':<7} | 443  | {ip:<15} | {'-':<6} | {'-'}")
        return

    server = tls_server_banner(domain, ip)

    for method in ['HEAD', 'GET']:
        code = curl_http(domain, ip, method)
        print(f"{domain:<18} | {server:<7} | 443  | {ip:<15} | {method:<6} | {code}")

def start_scan(domains):
    threads = []
    for domain in domains:
        t = threading.Thread(target=scan_sni, args=(domain.strip(),))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

def main():
    while True:
        print("\n🌐 TSHACKER SNI SCANNER 🌐")
        print("1️⃣ Scan single domain")
        print("2️⃣ Scan multiple domains (comma-separated)")
        print("3️⃣ Scan from file (one domain per line)")
        print("4️⃣ Exit")
        choice = input("Select: ").strip()

        if choice == '1':
            domain = input("Enter SNI/domain: ").strip()
            print(f"\n{'SNI':<18} | {'SERVER':<7} | {'PORT'} | {'IP':<15} | {'METHOD':<6} | {'HTTP CODE'}")
            print('-' * 70)
            scan_sni(domain)

        elif choice == '2':
            bulk = input("Enter domains (comma-separated): ").strip()
            domains = bulk.split(',')
            print(f"\n{'SNI':<18} | {'SERVER':<7} | {'PORT'} | {'IP':<15} | {'METHOD':<6} | {'HTTP CODE'}")
            print('-' * 70)
            start_scan(domains)

        elif choice == '3':
            filename = input("Enter file path: ").strip()
            try:
                with open(filename) as f:
                    domains = [line.strip() for line in f if line.strip()]
                print(f"\n{'SNI':<18} | {'SERVER':<7} | {'PORT'} | {'IP':<15} | {'METHOD':<6} | {'HTTP CODE'}")
                print('-' * 70)
                start_scan(domains)
            except FileNotFoundError:
                print("❗ File not found.")

        elif choice == '4':
            print("Exiting... 🚀")
            sys.exit(0)

        else:
            print("❗ Invalid option. Try again.")

if __name__ == "__main__":
    main()
